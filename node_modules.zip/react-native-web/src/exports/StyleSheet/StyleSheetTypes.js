/**
 * Copyright (c) Nicolas Gallagher.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 *
 * @flow
 */

type Atom = number | boolean | Object | Array<?Atom>;
export type StyleObj = Atom;
