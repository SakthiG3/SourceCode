import ViewPropTypes, {
  type ViewProps,
  type ViewLayout,
  type ViewLayoutEvent
} from '../View/ViewPropTypes';
export type { ViewProps, ViewLayout, ViewLayoutEvent };
export default ViewPropTypes;
