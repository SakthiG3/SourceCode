import TextPropTypes from '../Text/TextPropTypes';
export default TextPropTypes;
