# react-native-web

"React Native for Web" brings the platform-agnostic Components and APIs of
React Native to the Web. It is used in production by Twitter Lite.

Read more: https://github.com/necolas/react-native-web
