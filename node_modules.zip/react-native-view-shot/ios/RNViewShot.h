
#import <React/RCTBridgeModule.h>

@interface RNViewShot : NSObject <RCTBridgeModule>

@end
  
