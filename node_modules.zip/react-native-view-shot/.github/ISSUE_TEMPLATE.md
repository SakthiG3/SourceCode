### feature request

<!-- ---? OR ?--- -->

### bug report <!-- Please provide enough information. issues missing information will get closed -->

#### Version & Platform

```bash
npm ls react-native react-native-view-shot #<- PASTE CMD RESULT IN HERE
```

**Platform:** iOS? Android?

#### Expected behavior

#### Actual behavior

#### Steps to reproduce the behavior
<!-- Ideally please use the example app to reproduce it, if it does not reproduce, worth PR the example to add a repro case -->
