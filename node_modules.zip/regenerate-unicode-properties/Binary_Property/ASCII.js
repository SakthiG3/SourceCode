const set = require('regenerate')();
set.addRange(0x0, 0x7F);
module.exports = set;
