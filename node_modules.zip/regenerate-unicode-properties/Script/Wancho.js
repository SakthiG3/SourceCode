const set = require('regenerate')(0x1E2FF);
set.addRange(0x1E2C0, 0x1E2F9);
module.exports = set;
