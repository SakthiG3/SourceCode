const set = require('regenerate')();
set.addRange(0xA4D0, 0xA4FF);
module.exports = set;
