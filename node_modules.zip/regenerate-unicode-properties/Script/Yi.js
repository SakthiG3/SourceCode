const set = require('regenerate')();
set.addRange(0xA000, 0xA48C).addRange(0xA490, 0xA4C6);
module.exports = set;
