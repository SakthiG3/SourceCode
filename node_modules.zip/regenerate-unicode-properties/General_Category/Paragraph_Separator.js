const set = require('regenerate')(0x2029);

module.exports = set;
