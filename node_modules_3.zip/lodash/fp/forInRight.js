var convert = require('./convert'),
    func = convert('forInRight', require('../forInRight'));

func.placeholder = require('./placeholder');
module.exports = func;
