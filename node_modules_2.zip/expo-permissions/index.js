module.exports = {
  get Permissions() {
    return require('./src/Permissions');
  },
};
