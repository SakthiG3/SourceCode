export * from 'react-native/Libraries/Image/AssetRegistry';
