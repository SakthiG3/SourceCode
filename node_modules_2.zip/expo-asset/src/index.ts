import './Asset.fx';

export * from './Asset';
