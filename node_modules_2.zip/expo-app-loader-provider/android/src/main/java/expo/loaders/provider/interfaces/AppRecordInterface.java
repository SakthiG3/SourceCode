package expo.loaders.provider.interfaces;

public interface AppRecordInterface {
  void invalidate();
}
