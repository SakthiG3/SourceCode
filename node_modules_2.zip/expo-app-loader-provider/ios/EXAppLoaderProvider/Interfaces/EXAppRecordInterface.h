// Copyright 2018-present 650 Industries. All rights reserved.

@protocol EXAppRecordInterface <NSObject>

- (void)invalidate;

@end
