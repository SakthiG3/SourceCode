export const { openDatabase } = global;
export default { openDatabase };
