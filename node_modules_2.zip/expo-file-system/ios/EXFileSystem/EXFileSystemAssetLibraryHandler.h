
#import <EXFileSystem/EXFileSystem.h>

@interface EXFileSystemAssetLibraryHandler : NSObject <EXFileSystemHandler>

@end
