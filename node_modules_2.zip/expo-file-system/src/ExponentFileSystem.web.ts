import ExponentFileSystemShim from './ExponentFileSystemShim';
export default ExponentFileSystemShim;
