import { NativeModulesProxy } from '@unimodules/core';
export default NativeModulesProxy.ExpoWebBrowser || ({} as any);
