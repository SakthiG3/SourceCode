// Copyright 2016-present 650 Industries. All rights reserved.

#import <UMPermissionsInterface/UMPermissionsInterface.h>

@interface EXLocationPermissionRequester : NSObject<UMPermissionsRequester>

@end
