package expo.modules.location;

public interface LocationActivityResultListener {
  void onResult(int resultCode);
}
