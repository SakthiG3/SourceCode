import { NativeModulesProxy } from '@unimodules/core';
export default NativeModulesProxy.ExpoErrorRecovery || {};
