export { default as LinearGradient } from './LinearGradient';
