// Copyright 2015-present 650 Industries. All rights reserved.

#import <UMCore/UMViewManager.h>
#import <UMCore/UMExportedModule.h>

@interface EXLinearGradientManager : UMViewManager

@end
