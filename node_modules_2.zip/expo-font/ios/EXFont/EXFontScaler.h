// Copyright 2015-present 650 Industries. All rights reserved.

#import <Foundation/Foundation.h>
#import <UMFontInterface/UMFontScalerInterface.h>

@interface EXFontScaler : NSObject <UMFontScalerInterface>

@end
