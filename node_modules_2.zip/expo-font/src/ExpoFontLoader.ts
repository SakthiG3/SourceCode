import { NativeModulesProxy } from '@unimodules/core';
export default NativeModulesProxy.ExpoFontLoader;
