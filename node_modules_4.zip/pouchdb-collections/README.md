PouchDB Collections
=======

Super-minimal ES6 Map and Set shims for PouchDB. Published as a separate repo so that Browserify can correctly collapse it when used in both PouchDB and PouchDB map/reduce modules.