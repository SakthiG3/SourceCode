# noop-fn

It's noop function. It does nothing.

## Install
```
npm install noop-fn
```

## Usage
```js
var noop = require('noop-fn');

noop(); // Nothing happened
```


## Author
[Ivan Nikulin](https://github.com/inikulin) (ifaaan@gmail.com)

