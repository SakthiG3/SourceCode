# Installation
> `npm install --save @types/lodash.zipobject`

# Summary
This package contains type definitions for lodash.zipObject ( https://lodash.com ).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/lodash.zipobject

Additional Details
 * Last updated: Mon, 04 Mar 2019 23:26:53 GMT
 * Dependencies: @types/lodash
 * Global values: none

# Credits
These definitions were written by Brian Zengel <https://github.com/bczengel>, Ilya Mochalov <https://github.com/chrootsu>, Stepan Mikhaylyuk <https://github.com/stepancar>.
