import { add } from "./index";
export = add;
