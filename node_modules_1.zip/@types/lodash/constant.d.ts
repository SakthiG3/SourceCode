import { constant } from "./index";
export = constant;
