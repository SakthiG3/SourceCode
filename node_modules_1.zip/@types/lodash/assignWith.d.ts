import { assignWith } from "./index";
export = assignWith;
