# Installation
> `npm install --save @types/fbemitter`

# Summary
This package contains type definitions for Facebook's EventEmitter 2.0.0 (https://github.com/facebook/emitter).

# Details
Files were exported from https://www.github.com/DefinitelyTyped/DefinitelyTyped/tree/types-2.0/fbemitter

Additional Details
 * Last updated: Mon, 19 Sep 2016 17:28:58 GMT
 * File structure: ProperModule
 * Library Dependencies: none
 * Module Dependencies: none
 * Global values: none

# Credits
These definitions were written by kmxz <https://github.com/kmxz>.
