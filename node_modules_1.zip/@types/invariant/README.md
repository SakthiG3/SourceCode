# Installation
> `npm install --save @types/invariant`

# Summary
This package contains type definitions for invariant (https://github.com/zertosh/invariant).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/invariant.

### Additional Details
 * Last updated: Fri, 20 Dec 2019 06:33:41 GMT
 * Dependencies: none
 * Global values: `invariant`

# Credits
These definitions were written by MichaelBennett (https://github.com/bennett000), dtinth (https://github.com/dtinth), and Turadg Aleahmad (https://github.com/turadg).
