import createIconSetFromFontello from './build/createIconSetFromFontello';
export default createIconSetFromFontello;
