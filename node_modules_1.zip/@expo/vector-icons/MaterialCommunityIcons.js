import MaterialCommunityIcons from './build/MaterialCommunityIcons';
export default MaterialCommunityIcons;
