import createIconSet from './build/createIconSet';
export default createIconSet;
