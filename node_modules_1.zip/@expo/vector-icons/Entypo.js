import Entypo from './build/Entypo';
export default Entypo;
