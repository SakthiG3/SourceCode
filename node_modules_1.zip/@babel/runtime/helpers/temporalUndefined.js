function _temporalUndefined() {}

module.exports = _temporalUndefined;