function _AwaitValue(value) {
  this.wrapped = value;
}

module.exports = _AwaitValue;